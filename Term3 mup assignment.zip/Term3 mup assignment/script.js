//Accordion code
const accordion = document.getElementsByClassName('contentBx');

//adds a click event listener to each accordion item, toggling its active class
for (let i = 0; i < accordion.length; i++) {
    accordion[i].addEventListener('click', function() {
        this.classList.toggle('active');

        let content = this.querySelector('.content');
        let icon = this.querySelector('.icon');

    });
}

// Pagination code
const paginationLinks = document.querySelectorAll('.pag li');
const leftArrow = document.querySelector('.left-btn');
const rightArrow = document.querySelector('.right-btn');
let currentIndex = 0;

// Function to open an accordion panel based on index
function openAccordion(index) {
    closeAllAccordions();
    accordion[index].classList.add('active');
    let content = accordion[index].querySelector('.content');
    content.style.maxHeight = content.scrollHeight + 'px'; // Set maxHeight
    accordion[index].querySelector('.icon').textContent = '-';
    updatePaginationHighlight(index);
}

// Function to close all accordion panels
function closeAllAccordions() {
    for (let i = 0; i < accordion.length; i++) {
        let content = accordion[i].querySelector('.content');
        let icon = accordion[i].querySelector('.icon');
        accordion[i].classList.remove('active');
        content.style.maxHeight = null; 
        icon.textContent = '+';
    }
}


function updatePaginationHighlight(index) {
    paginationLinks.forEach((link, i) => {
        if (i === index) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });
}


paginationLinks.forEach((link, index) => {
    link.addEventListener('click', function () {
        currentIndex = index;
        openAccordion(currentIndex);
    });
});

// Arrow button click events
leftArrow.addEventListener('click', function () {
    if (currentIndex > 0) {
        currentIndex--;
        openAccordion(currentIndex);
    }
});

rightArrow.addEventListener('click', function () {
    if (currentIndex < paginationLinks.length - 1) {
        currentIndex++;
        openAccordion(currentIndex);
    }

    setSameHeight();
});














